package tikape.runko;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import spark.ModelAndView;
import static spark.Spark.*;
import spark.template.thymeleaf.ThymeleafTemplateEngine;
import tikape.runko.database.AihealueDao;
import tikape.runko.database.Database;
import tikape.runko.database.KetjuDao;
import tikape.runko.database.ViestiDao;
import tikape.runko.domain.Aihealue;
import tikape.runko.domain.Ketju;
import tikape.runko.domain.Viesti;

public class Main {

    public static void main(String[] args) throws Exception {
        Database database = new Database("jdbc:sqlite:foorumi2.db");
        database.init();

        AihealueDao aDao = new AihealueDao(database);
        KetjuDao kDao = new KetjuDao(database);
        ViestiDao vDao = new ViestiDao(database);
        
        Integer indeksi = 1;

        get("/", (req, res) -> {
            HashMap map = new HashMap<>();
            map.put("aihealueet", aDao.findAll());
            return new ModelAndView(map, "index");
        }, new ThymeleafTemplateEngine());

        post("/", (req, res) -> {
            String aihe = req.queryParams("aihe");
            System.out.println(aihe);
            if (aihe.isEmpty()) {
                res.redirect("/");
                return null;
            }

            aDao.add(new Aihealue(aihe));
            res.redirect("/");

            return null;
        });
        
        get("/:aihealue", (req, res) -> {
            HashMap map = new HashMap<>();
            map.put("ketjut", kDao.findByAihealue(req.params(":aihealue")));
            return new ModelAndView(map, "ketjut");
        }, new ThymeleafTemplateEngine());
        
        post("/:aihealue", (req, res) -> {
            String otsikko = req.queryParams("Otsikko");
            String sisalto = req.queryParams("Sisältö");
            String kayttajanimi = req.queryParams("Käyttäjänimi");
            
            if (otsikko.isEmpty() || sisalto.isEmpty() || kayttajanimi.isEmpty()) {
                res.redirect("/" + req.params(":aihealue"));
                return null;
            }
            
            Ketju t = new Ketju(indeksi, req.params(":aihealue"), otsikko, sisalto, kayttajanimi);
            kDao.add(t);
            t.setAloitusaika(kDao.getAloitusaika(indeksi));
            
//            indeksi++;
            
            res.redirect("/" + req.params(":aihealue"));

            return null;
        });
        
        get("/:aihealue/:ketjuid", (req, res) -> {
            HashMap map = new HashMap<>();
            Ketju k = kDao.findOne(Integer.parseInt(req.params(":ketjuid")));
            Viesti a = new Viesti(k.getKetju(), k.getSisalto(), k.getKayttajanimi(), k.getAloitusaika());
            ArrayList<Viesti> ka = new ArrayList<>();
            ka.add(a);
            
            for (Viesti viesti : vDao.findByKetju(k)) {
                ka.add(viesti);
            }
            
            map.put("otsikko", k.getOtsikko());
            map.put("viestit", ka);
            return new ModelAndView(map, "data");
        }, new ThymeleafTemplateEngine());
        
    }
    
}
