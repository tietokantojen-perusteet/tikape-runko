/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tikape.runko.domain;

/**
 *
 * @author aleksimu
 */
public class Ketju {
    private int ketju;
    private String aihe;
    private String otsikko;
    private String sisalto;
    private String aloitusaika;
    private String kayttajanimi;
    private int koko;
    private String viimeisin;
   
    public Ketju(Integer ketju, String aihe, String otsikko, String sisalto, String aloitusaika, String kayttajanimi) {
        this.ketju = ketju;
        this.aihe = aihe;
        this.otsikko = otsikko;
        this.sisalto = sisalto;
        this.aloitusaika = aloitusaika;
        this.kayttajanimi = kayttajanimi;
    }
    
    public Ketju(Integer ketju, String aihe, String otsikko, String sisalto, String kayttajanimi) {
        this.ketju = ketju;
        this.aihe = aihe;
        this.otsikko = otsikko;
        this.sisalto = sisalto;
//        this.aloitusaika = aloitusaika;
        this.kayttajanimi = kayttajanimi;
    }
    
    public Ketju(Integer ketju, String aihe, String otsikko, String sisalto) {
        this.ketju = ketju;
        this.aihe = aihe;
        this.otsikko = otsikko;
        this.sisalto = sisalto;
//        this.aloitusaika = aloitusaika;
        this.kayttajanimi = "Anonyymi";
    }

    public Integer getKetju() {
        return this.ketju;
    }

    public void setKetju(Integer id) {
        this.ketju = id;
    }

    public String getAihe() {
        return this.aihe;
    }

    public void setAihe(String nimi) {
        this.aihe = nimi;
    }
    
    public String getOtsikko(){
        return this.otsikko;
    }
    
    public void setOtsikko(String otsikko){
        this.otsikko = otsikko;
    }
    
    public String getSisalto(){
        return this.sisalto;
    } 
    
    public void setSisalto(String sisalto){
        this.sisalto = sisalto;
    }
    
    public void setKoko(int koko){
        this.koko = koko;
    }
    
    public int getKoko(){
        return this.koko;
    }
    
    public String getAloitusaika(){
        return this.aloitusaika;
    } 
    
    public void setAloitusaika(String aloitusaika){
        this.aloitusaika = aloitusaika;
    }
    
    public String getKayttajanimi(){
        return this.kayttajanimi;
    } 
    
    public void setKayttajanimi(String kayttajanimi){
        this.kayttajanimi = kayttajanimi;
    }
    
    public String getViimeisin(){
        return this.viimeisin;
    }
    
    public void setViimeisin(String v){
        this.viimeisin = v;
    }
    
}

