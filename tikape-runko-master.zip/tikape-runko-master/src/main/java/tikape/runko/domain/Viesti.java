
package tikape.runko.domain;

import java.sql.Date;
import java.sql.Time;

public class Viesti {
    private Integer id;
    private String kirjoittaja;
    private String sisalto;
    private Integer aiheid;
    private Date pvm;
    private Time tunnit;

    public Viesti(Integer id, String kirjoittaja, String sisalto, Integer aiheid, Date pvm, Time tunnit) {
        this.id = id;
        this.kirjoittaja = kirjoittaja;
        this.sisalto = sisalto;
        this.aiheid = aiheid;
        this.pvm = pvm;
        this.tunnit = tunnit;
    }

    public Viesti(String kirjoittaja, String sisalto, Integer aiheid, Date pvm, Time tunnit) {
        this(null, kirjoittaja, sisalto, aiheid, pvm, tunnit);
    }

    public Integer getId() {
        return id;
    }

    public Integer getAiheid() {
        return aiheid;
    }

    public String getKirjoittaja() {
        return kirjoittaja;
    }

    public String getSisalto() {
        return sisalto;
    }

    public Date getPvm() {
        return pvm;
    }

    public Time getTunnit() {
        return tunnit;
    }

    public void setAiheid(Integer aiheid) {
        this.aiheid = aiheid;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setKirjoittaja(String kirjoittaja) {
        this.kirjoittaja = kirjoittaja;
    }

    public void setPvm(Date pvm) {
        this.pvm = pvm;
    }

    public void setSisalto(String sisalto) {
        this.sisalto = sisalto;
    }

    public void setTunnit(Time tunnit) {
        this.tunnit = tunnit;
    }
    
    
    
    
    
    
    
}
