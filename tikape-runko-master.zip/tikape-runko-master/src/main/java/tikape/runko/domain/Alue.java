/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tikape.runko.domain;

public class Alue {
    private Integer id;
    private String nimi;
    private String kuvaus;

    public Alue(Integer id, String nimi, String kuvaus) {
        this.id = id;
        this.nimi = nimi;
        this.kuvaus = kuvaus;
    }

    public Alue(String nimi, String kuvaus) {
        this(null, nimi, kuvaus);
    }

    public Integer getId() {
        return id;
    }

    public String getKuvaus() {
        return kuvaus;
    }

    public String getNimi() {
        return nimi;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setKuvaus(String kuvaus) {
        this.kuvaus = kuvaus;
    }

    public void setNimi(String nimi) {
        this.nimi = nimi;
    }
    
    
    
    
    
}
