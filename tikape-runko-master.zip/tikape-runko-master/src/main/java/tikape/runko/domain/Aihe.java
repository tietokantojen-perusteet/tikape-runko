/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tikape.runko.domain;

import java.sql.Date;
import java.sql.Time;

public class Aihe {
    private Integer id;
    private Integer alueid;
    private String kirjoittaja;
    private String sisalto;
    private String nimi;
    private String aika;

    public Aihe(Integer id, Integer alueid, String kirjoittaja, String nimi,String sisalto, String aika) {
        this.id = id;
        this.nimi = nimi;
        this.kirjoittaja = kirjoittaja;
        this.alueid = alueid;
        this.sisalto = sisalto;
        this.aika = aika;
    }

    public Aihe(Integer alueid, String kirjoittaja, String nimi, String sisalto, String aika) {
        this(null, alueid, kirjoittaja, nimi, sisalto, aika);
    }

    public Integer getAlueid() {
        return alueid;
    }

    public Integer getId() {
        return id;
    }

    public String getNimi() {
        return nimi;
    }

    public void setNimi(String nimi) {
        this.nimi = nimi;
    }

    public String getAika() {
        return aika;
    }

    public void setAika(String aika) {
        this.aika = aika;
    }


    public String getSisalto() {
        return sisalto;
    }



    public void setAlueid(Integer alueid) {
        this.alueid = alueid;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    

    public void setSisalto(String sisalto) {
        this.sisalto = sisalto;
    }

    
    
    
    
}
