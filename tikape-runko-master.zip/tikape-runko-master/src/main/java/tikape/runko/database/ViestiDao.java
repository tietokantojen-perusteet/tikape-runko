/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tikape.runko.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import tikape.runko.domain.Viesti;

public class ViestiDao implements Dao<Viesti, Integer>{
    private Database database;

    public ViestiDao(Database database) {
        this.database = database;
    }

    @Override
    public Viesti findOne(Integer key) throws SQLException {
        Connection connection = database.getConnection();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Viesti WHERE id = ?");
        stmt.setObject(1, key);

        ResultSet rs = stmt.executeQuery();
        boolean hasOne = rs.next();
        if (!hasOne) {
            return null;
        }

        Integer id = rs.getInt("id");
        String nimi = rs.getString("kirjoittaja");
        String sisalto = rs.getString("sisalto");
        Integer aiheid = rs.getInt("aiheid");
        String aika = rs.getString("aika");

        

        rs.close();
        stmt.close();
        connection.close();

        return null;
    }

    @Override
    public List<Viesti> findAll() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Integer key) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<String> getViestit(String aihe) throws SQLException {
        Connection conn = database.getConnection();
        //käyttötapaus 3/3
        PreparedStatement stmt = conn.prepareStatement("SELECT Viesti.moneskoviesti, Viesti.sisalto, Viesti.id FROM Viesti WHERE Viesti.aiheid = (SELECT aihe.id FROM aihe WHERE aihe.nimi = '" +aihe +"') ORDER BY moneskoViesti ASC");

        ResultSet rs = stmt.executeQuery();
        List<String> viestit = new ArrayList<>();
        while (rs.next()) {
            String one = rs.getString(1);
            String two = rs.getString(2);
            String three = rs.getString(3);

            viestit.add(one +"\t" +two +"\t" +three);
        }

        rs.close();
        stmt.close();
        conn.close();

        return viestit;
    }
    
}
