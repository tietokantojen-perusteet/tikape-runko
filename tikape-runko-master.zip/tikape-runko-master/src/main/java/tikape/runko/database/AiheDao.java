/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tikape.runko.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import tikape.runko.domain.Aihe;

public class AiheDao implements Dao<Aihe, Integer> {
    
    private Database database;

    public AiheDao(Database database) {
        this.database = database;
    }

    @Override
    public Aihe findOne(Integer key) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Aihe> findAll() throws SQLException {
        Connection conn = database.getConnection();
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Aihe");
        
        ResultSet rs = stmt.executeQuery();
        List<Aihe> aiheet = new ArrayList<>();
        while(rs.next()) {
            Integer id = rs.getInt("id");
            Integer alueid = rs.getInt("alueid");
            String nimi = rs.getString("nimi");
            String sisalto = rs.getString("sisalto");
            String aika = rs.getString("aika");
            String kirjoittaja = rs.getString("kirjoittaja");
            
            aiheet.add(new Aihe(id, alueid, kirjoittaja, nimi, sisalto, aika));

        }
        
        return aiheet;
    }

    @Override
    public void delete(Integer key) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<String> getAiheet(String alue) throws SQLException {
        Connection connection = database.getConnection();
        //käyttötapaus 2/3 kysely
        PreparedStatement stmt = connection.prepareStatement("SELECT Aihe.nimi AS 'Alue: " +alue +"', COUNT(viesti.id) AS 'Viestejä', viesti.aika AS 'Viimeisin viesti' FROM Alue LEFT JOIN Aihe ON Aihe.alueid = alue.id LEFT JOIN viesti ON viesti.aiheid = aihe.id WHERE alue.nimi = '" +alue +"' GROUP BY Aihe.id ORDER BY COUNT(viesti.id) DESC");

        ResultSet rs = stmt.executeQuery();
        List<String> aiheet = new ArrayList<>();
        while (rs.next()) {
            String one = rs.getString(1);
            String two = rs.getString(2);
            String three = rs.getString(3);

            aiheet.add(one +"\t" +two +"\t" +three);
        }

        rs.close();
        stmt.close();
        connection.close();

        return aiheet;
    }
    
}
