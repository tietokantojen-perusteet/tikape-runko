/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tikape.runko.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import tikape.runko.domain.Alue;

public class AlueDao implements Dao<Alue, Integer>{
    private Database database;

    public AlueDao(Database database) {
        this.database = database;
    }

    @Override
    public Alue findOne(Integer key) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Alue> findAll() throws SQLException {
        Connection connection = database.getConnection();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM alue");
        ResultSet rs = stmt.executeQuery();
        List<Alue> alueet = new ArrayList<>();
        while (rs.next()) {
            Integer one = rs.getInt("id");
            String two = rs.getString("nimi");
            String three = rs.getString("kuvaus");

            alueet.add(new Alue(one, two, three));
        }

        rs.close();
        stmt.close();
        connection.close();

        return alueet;
    }

    @Override
    public void delete(Integer key) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<String> getAlueet() throws SQLException {
        Connection connection = database.getConnection();
        //käyttötapaus 1/3 kysely
        PreparedStatement stmt =
                connection.prepareStatement("SELECT Alue.nimi AS Alue, COUNT(Viesti.id) AS 'Viestejä yhteensä', viesti.aika FROM Alue LEFT JOIN Aihe ON Alue.id = Aihe.Alueid LEFT JOIN Viesti ON Aihe.id = Viesti.aiheid GROUP BY Alue.id ORDER BY COUNT(viesti.id) DESC");

        ResultSet rs = stmt.executeQuery();
        List<String> alueet = new ArrayList<>();
        while (rs.next()) {
            String one = rs.getString(1);
            String two = rs.getString(2);
            String three = rs.getString(3);

            alueet.add(one +"\t" +two +"\t" +three);
        }

        rs.close();
        stmt.close();
        connection.close();

        return alueet;
    }
}
